/** Date: 2018-08-20 23:12:42. */
package org.test.hexpression;

/**
 * Date: 2018-08-20 23:12:42.
 *
 * @author: lizhipeng.
 * @description:
 */
public class HExpException extends RuntimeException {

  /** serialVersionUID:. */
  private static final long serialVersionUID = -1642593415269841503L;

  public HExpException() {}

  public HExpException(String message) {
    super(message);
  }
}
