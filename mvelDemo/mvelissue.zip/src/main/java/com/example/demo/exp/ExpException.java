package com.example.demo.exp;

public class ExpException extends RuntimeException {

  /**
   * 
   */
  private static final long serialVersionUID = 7142280673091799953L;

  public ExpException() {}

  public ExpException(String message) {
    super(message);
  }
}
